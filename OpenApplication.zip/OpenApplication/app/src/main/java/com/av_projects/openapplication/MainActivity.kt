package com.av_projects.openapplication

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CallLog
import android.provider.MediaStore
import android.widget.Button
import android.widget.Gallery

class MainActivity : AppCompatActivity() {
    lateinit var galleryBtn: Button
    lateinit var phLogBtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        galleryBtn = findViewById(R.id.galleryBtn)
        galleryBtn.setOnClickListener {
            Intent(Intent.ACTION_PICK).setType("image/*").apply {
                startActivity(this)
            }
        }
        phLogBtn = findViewById(R.id.phlogBtn)
        phLogBtn.setOnClickListener {
            Intent(Intent.ACTION_VIEW).setType(CallLog.Calls.CONTENT_TYPE).apply {
                startActivity(this)
            }
        }

    }
}