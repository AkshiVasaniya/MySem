package com.av_projects.demo

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.annotation.RequiresApi
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var Logo: ImageView
    lateinit var MainBtn: Button
    lateinit var rotateAnim: Animation

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Logo = findViewById(R.id.logo)
        MainBtn = findViewById(R.id.mainBtn)

        //rotate
        rotateAnim = AnimationUtils.loadAnimation(applicationContext, R.anim.rotate)
        Logo.startAnimation(rotateAnim)


        MainBtn.setOnClickListener{
            startActivity(Intent(applicationContext, SecondActivity::class.java))
            overridePendingTransition(R.anim.slide_right, R.anim.slide_left)
        }
    }
}