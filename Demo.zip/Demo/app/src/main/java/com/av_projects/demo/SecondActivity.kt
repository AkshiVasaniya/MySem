package com.av_projects.demo

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.Keyboard
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import org.w3c.dom.Text
import java.lang.reflect.Modifier

class SecondActivity : AppCompatActivity() {
    var x = 0
    lateinit var colorBtn: Button
    lateinit var backBtn: Button
    lateinit var constraintLayout: ConstraintLayout
    lateinit var drawable: GradientDrawable
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        backBtn = findViewById(R.id.backBtn)
        backBtn.setOnClickListener {
            startActivity(Intent(applicationContext, MainActivity::class.java))
            overridePendingTransition(R.anim.slide_left, R.anim.slide_right)
        }

        colorBtn = findViewById(R.id.colorBtn)
        constraintLayout = findViewById(R.id.secondActivity)
        colorBtn.setOnClickListener {
            if(x == 0){
                var drawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.WHITE, Color.GRAY))
                drawable.cornerRadius = 0f
                constraintLayout.setBackgroundDrawable(drawable)
                x++
            } else{
                var drawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(R.color.purple_200, Color.WHITE))
                drawable.cornerRadius = 0f
                constraintLayout.setBackgroundDrawable(drawable)
                x--
            }
        }


    }
}