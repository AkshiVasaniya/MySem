package com.av_projects.googlemaps

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var mapBtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mapBtn = findViewById(R.id.mapBtn)
        mapBtn.setOnClickListener {
            Intent(applicationContext, MapsActivity::class.java).apply {
                startActivity(this)
            }
        }
    }
}